/**
 * useCategoryFromNav
 *
 * Use inside ProjectsPage, EventsPage, GalleryPage.
 * Returns the initial category to display, driven by:
 *   1. sessionStorage 'setCategory'  (set by Header submenu on cross-page nav)
 *   2. Custom event 'submenu-set-category'  (set by Header submenu on same-page nav)
 *
 * @param setCategory  React setState setter for the page's selectedCategory
 */
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export function useCategoryFromNav(setCategory: (c: string) => void) {
  const location = useLocation();

  // On mount / navigation: read sessionStorage
  useEffect(() => {
    const stored = sessionStorage.getItem('setCategory');
    if (stored) {
      sessionStorage.removeItem('setCategory');
      setCategory(stored);
      // Scroll to top so the filter change is visible
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [location.pathname]);

  // Same-page: listen for custom event
  useEffect(() => {
    function handler(e: Event) {
      const cat = (e as CustomEvent<string>).detail;
      setCategory(cat);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    window.addEventListener('submenu-set-category', handler);
    return () => window.removeEventListener('submenu-set-category', handler);
  }, [setCategory]);
}
